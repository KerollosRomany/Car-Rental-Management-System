using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Threading.Tasks;
using wayfare_backend.Dtos.AuthDtos;
using wayfare_backend.Models;
using wayfare_backend.Services;
using System.Linq;

namespace wayfare_backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly AppDbContext _context;
        private readonly IImageService _imageService;
        private readonly JwtTokenService _jwtTokenService;

        public AuthenticationController(
            UserManager<ApplicationUser> userManager,
            AppDbContext context,
            IImageService imageService,
            JwtTokenService jwtTokenService)
        {
            _userManager = userManager;
            _context = context;
            _imageService = imageService;
            _jwtTokenService = jwtTokenService;
        }

        [HttpPost("register")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> Register([FromForm] RegisterRequestDto request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Check if the email is already registered
            var existingUser = await _userManager.FindByEmailAsync(request.Email);
            if (existingUser != null)
                return BadRequest(new { Message = "Email is already registered." });

            // Upload the license image to Cloudflare R2
            var licenseImageUrl = await _imageService.UploadImageAsync(request.LicenseImage, "licenses");
            if (string.IsNullOrEmpty(licenseImageUrl))
                return BadRequest(new { Message = "Failed to upload license image." });

            // Create the base application user matching the ApplicationUser model
            var user = new ApplicationUser
            {
                UserName = request.Email,
                Email = request.Email,
                PhoneNumber = request.PhoneNumber,
                FullName = request.FullName
            };

            var result = await _userManager.CreateAsync(user, request.Password);
            if (!result.Succeeded)
            {
                // If user creation fails, delete the uploaded image to prevent orphaned files
                await _imageService.DeleteImageAsync(licenseImageUrl);
                return BadRequest(result.Errors);
            }

            // Assign the "Customer" role to the user
            await _userManager.AddToRoleAsync(user, "Customer");

            // Create the customer profile matching the exact properties in the Customer model
            var customer = new Customer
            {
                UserId = user.Id,
                LicenseExp = request.LicenseExp,
                LicenseState = request.LicenseState,
                LicenseImageUrl = licenseImageUrl
            };

            _context.Customers.Add(customer);
            await _context.SaveChangesAsync();

            return Ok(new { Message = "User registered successfully." });
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var user = await _userManager.FindByEmailAsync(request.Email);
            if (user == null || !await _userManager.CheckPasswordAsync(user, request.Password))
            {
                return Unauthorized(new { Message = "Invalid email or password." });
            }

            var roles = await _userManager.GetRolesAsync(user);

            // Generate token using the correct async method
            var token = await _jwtTokenService.CreateTokenAsync(user);

            return Ok(new { Token = token, Roles = roles });
        }

        [HttpPost("change-password")]
        [Authorize] 
        public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequestDto request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // 1. Extract the user ID from the JWT token claims
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null)
                return Unauthorized(new { message = "User not found or token is invalid." });

            // 2. Find the user in the database
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
                return NotFound(new { message = "User does not exist." });

            // 3. Change the password using the built-in Identity method
            var result = await _userManager.ChangePasswordAsync(user, request.CurrentPassword, request.NewPassword);

            if (result.Succeeded)
            {
                return Ok(new { message = "Password changed successfully." });
            }

            // 4. If the current password is wrong or any other validation fails, return the errors
            var errors = result.Errors.Select(e => e.Description);
            return BadRequest(new { errors });
        }

        [HttpGet("profile")]
        [Authorize]
        public async Task<IActionResult> GetUserProfile()
        {
            // 1. Extract User ID from the token
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null)
                return Unauthorized(new { message = "User not found or token is invalid." });

            // 2. Fetch User from Identity
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
                return NotFound(new { message = "User does not exist." });

            // 3. Fetch Customer details (License info) from the database
            var customer = await _context.Customers.FirstOrDefaultAsync(c => c.UserId == userId);

            // 4. Map the data to the DTO
            var profileDto = new UserProfileDto
            {
                FullName = user.FullName ?? string.Empty,
                Email = user.Email ?? string.Empty,
                PhoneNumber = user.PhoneNumber ?? string.Empty,
                LicenseExp = customer?.LicenseExp,
                LicenseState = customer?.LicenseState ?? default,
                LicenseImageUrl = customer?.LicenseImageUrl
            };

            return Ok(profileDto);
        }
        [HttpPut("profile")]
[Authorize]
public async Task<IActionResult> UpdateProfile([FromBody] UpdateProfileRequestDto request)
{
    if (!ModelState.IsValid)
        return BadRequest(ModelState);

    var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
    if (userId == null)
        return Unauthorized(new { message = "User not found or token is invalid." });

    var user = await _userManager.FindByIdAsync(userId);
    if (user == null)
        return NotFound(new { message = "User does not exist." });

    user.FullName = request.FullName;
    user.PhoneNumber = request.PhoneNumber;

    var result = await _userManager.UpdateAsync(user);
    if (!result.Succeeded)
    {
        var errors = result.Errors.Select(e => e.Description);
        return BadRequest(new { errors });
    }

    return Ok(new { message = "Profile updated successfully." });
}

        [HttpPut("license")]
        [Authorize]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UpdateLicense([FromForm] UpdateLicenseRequestDto request)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (userId == null)
                return Unauthorized(new { message = "User not found or token is invalid." });

            var customer = await _context.Customers.FirstOrDefaultAsync(c => c.UserId == userId);
            if (customer == null)
                return NotFound(new { message = "Customer profile not found." });

            customer.LicenseExp = request.LicenseExp;
            customer.LicenseState = request.LicenseState;

            if (request.LicenseImage != null)
            {
                var newImageUrl = await _imageService.UploadImageAsync(request.LicenseImage, "licenses");
                if (string.IsNullOrEmpty(newImageUrl))
                    return BadRequest(new { message = "Failed to upload new license image." });

            
                if (!string.IsNullOrEmpty(customer.LicenseImageUrl))
                {
                    await _imageService.DeleteImageAsync(customer.LicenseImageUrl);
                }

                customer.LicenseImageUrl = newImageUrl;
            }

            _context.Customers.Update(customer);
            await _context.SaveChangesAsync();

            return Ok(new { message = "License updated successfully." });
        }
    }
}
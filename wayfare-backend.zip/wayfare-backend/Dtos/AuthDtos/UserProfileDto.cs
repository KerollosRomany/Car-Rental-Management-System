using System;
using wayfare_backend.Enums.UserEnums;

namespace wayfare_backend.Dtos.AuthDtos
{
    public class UserProfileDto
    {
        public string FullName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public DateTime? LicenseExp { get; set; } 
        public UserLicense LicenseState { get; set; } 
        public string? LicenseImageUrl { get; set; }
    }
}